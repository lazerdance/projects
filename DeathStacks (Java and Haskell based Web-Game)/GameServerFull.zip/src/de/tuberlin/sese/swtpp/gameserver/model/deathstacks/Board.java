package de.tuberlin.sese.swtpp.gameserver.model.deathstacks;

import java.io.Serializable;

public class Board implements Serializable{

	private static final long serialVersionUID = 1L;
	
	public String[][] board;
	  
     // Board Matrix mit 1->6 column und row. 0 und 7 sind auf x zugewiesen als Rahmen
     // und 8 ist nicht zugreifbar
	 public Board() {
	     board = new String[8][8];
	     initializeBoard();
	     stringToMatrix("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb");
	 }
	 
	 public void initializeBoard() {
			for (int i=0; i<board.length;i++) {
				board[i][0] = "x";
				board[i][board.length-1] = "x";
			}
			for (int j=0; j<board.length;j++) {
				board[0][j] = "x";
				board[board.length-1][j] = "x";			
			}
			for (int i=1; i<board.length-1;i++) {
				for (int j=1; j<board.length-1;j++) {
					board[i][j] = "";
				}
			}
	 }
	 
	 public void stringToMatrix(String state) {
	 	initializeBoard();
	    CharSequence ssc = state.subSequence(0, state.length());
	    int i=board.length-2;
	    int j=1;
	    int x=0;
	    while(x < ssc.length()-1) {
			while(ssc.charAt(x) != ',' && ssc.charAt(x) != '/') {
				board[i][j] += String.valueOf(ssc.charAt(x));
				if(x >= ssc.length()-1)break;
				x++;
			}
			j++;
			if(ssc.charAt(x) == '/') { i--;j=1;}
			if(x >= ssc.length()-1)break;
			x++;
	    }
	 }
	     	 
	 public String toString() {
	    	String str = "";
	    	String Prefix = "";
	    	for(int i=board.length-2; i>=1; i--) {
	    		Prefix = "";
	    		for(int j=1; j<board[i].length-1; j++) {
	    			str += Prefix + board[i][j];
	    			Prefix = ",";
	    		}
	    		if(i > 1)
	    			str += "/";
	    	}return str;}
	        
}