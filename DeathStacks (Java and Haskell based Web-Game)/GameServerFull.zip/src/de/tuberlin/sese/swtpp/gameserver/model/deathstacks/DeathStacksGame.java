package de.tuberlin.sese.swtpp.gameserver.model.deathstacks;

import java.util.ArrayList;
import java.util.List;

import de.tuberlin.sese.swtpp.gameserver.model.Game;
import de.tuberlin.sese.swtpp.gameserver.model.Player;
// TODO: more imports allowed

public class DeathStacksGame extends Game {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -3053592017994489843L;
	/************************
	 * member
	 ***********************/
	
	// just for better comprehensibility of the code: assign blue and red player
	private Player bluePlayer;
	private Player redPlayer;

	// TODO: internal representation of the game state 
	/************************
	 * constructors
	 ***********************/
	Board board;
	List<String> boardHistory;
	
	public DeathStacksGame() throws Exception{
		super();
		
		// TODO: Initialization, if necessary
		boardHistory = new ArrayList<String>();
		board = new Board();
	}
	int rowStart, colStart, rowEnd, rowEnd2, colEnd, colEnd2, counter, steps,dimension;
	public String getType() {
		return "deathstacks";
	}
	
	/*******************************************
	 * Game class functions already implemented
	 ******************************************/
	
	@Override
	public boolean addPlayer(Player player) {
		if (!started) {
			players.add(player);
			
			if (players.size() == 2) {
				started = true;
				this.redPlayer = players.get(0);
				this.bluePlayer = players.get(1);
				nextPlayer = this.redPlayer;
			}
			return true;
		}
		
		return false;
	}

	@Override
	public String getStatus() {
		
		if (error) return "Error";
		if (!started) return "Wait";
		if (!finished) return "Started";
		if (surrendered) return "Surrendered";
		if (draw) return "Draw";
		
		return "Finished";
	}
	
	@Override
	public String gameInfo() {
		String gameInfo = "";
		
		if(started) {
			if(blueGaveUp()) gameInfo = "blue gave up";
			else if(redGaveUp()) gameInfo = "red gave up";
			else if(didRedDraw() && !didBlueDraw()) gameInfo = "red called draw";
			else if(!didRedDraw() && didBlueDraw()) gameInfo = "blue called draw";
			else if(draw) gameInfo = "draw game";
			else if(finished)  gameInfo = bluePlayer.isWinner()? "blue won" : "red won";
		}
			
		return gameInfo;
	}	
	
	@Override
	public String nextPlayerString() {
		return isRedNext()? "r" : "b";
	}

	@Override
	public int getMinPlayers() {
		return 2;
	}

	@Override
	public int getMaxPlayers() {
		return 2;
	}
	
	@Override
	public boolean callDraw(Player player) {
		
		// save to status: player wants to call draw 
		if (this.started && ! this.finished) {
			player.requestDraw();
		} else {
			return false; 
		}
	
		// if both agreed on draw:
		// game is over
		if(players.stream().allMatch(p -> p.requestedDraw())) {
			this.finished = true;
			this.draw = true;
			redPlayer.finishGame();
			bluePlayer.finishGame();
		}	
		return true;
	}
	
	@Override
	public boolean giveUp(Player player) {
		if (started && !finished) {
			if (this.redPlayer == player) { 
				redPlayer.surrender();
				bluePlayer.setWinner();
			}
			if (this.bluePlayer == player) {
				bluePlayer.surrender();
				redPlayer.setWinner();
			}
			finished = true;
			surrendered = true;
			redPlayer.finishGame();
			bluePlayer.finishGame();
			
			return true;
		}
		
		return false;
	}

	/*******************************************
	 * Helpful stuff
	 ******************************************/
	
	/**
	 * 
	 * @return True if it's white player's turn
	 */
	public boolean isRedNext() {
		return nextPlayer == redPlayer;
	}
	/*switch to next player
	 * 
	 */
	public void switchPlayer() {
		if (nextPlayer == redPlayer) nextPlayer = bluePlayer;
		else nextPlayer = redPlayer;
	}
	/**
	 * Finish game after regular move (save winner, move game to history etc.)
	 * 
	 * @param player
	 * @return
	 */
	public boolean finish(Player player) {
		// public for tests
		if (started && !finished) {
			player.setWinner();
			finished = true;
			redPlayer.finishGame();
			bluePlayer.finishGame();
			
			return true;
		}
		return false;
	}

	public boolean didRedDraw() {
		return redPlayer.requestedDraw();
	}

	public boolean didBlueDraw() {
		return bluePlayer.requestedDraw();
	}

	public boolean redGaveUp() {
		return redPlayer.surrendered();
	}

	public boolean blueGaveUp() {
		return bluePlayer.surrendered();
	}

	/*******************************************
	 * !!!!!!!!! To be implemented !!!!!!!!!!!!
	 ******************************************/
	
	@Override
	public void setBoard(String state) {
		// TODO: implement
		board.stringToMatrix(state);
	}
	
	@Override
	public String getBoard() {
		return board.toString();
		// TODO: replace with implementation
		}

	@Override
	public String[][] getBoardMatrix(){
		return board.board;
	}
	
	@Override
	public boolean tryMove(String moveString, Player player) {
		
		/* convert coordinates to integers 
		 * those integers will point to indices on the matrix
		 a and b are start index, c and d are dest index */
		// Move Start Coords
		if(boardHistory.size() == 0)boardHistory.add("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb");
		colStart = moveString.split("-")[0].charAt(0) - 96;rowStart = moveString.split("-")[0].charAt(1) - 48;		// Move dest Coords
		colEnd = moveString.split("-")[2].charAt(0) - 96;rowEnd = moveString.split("-")[2].charAt(1) - 48;
		steps = Integer.parseInt(moveString.split("-")[1]);
		rowEnd2=rowEnd; colEnd2=colEnd;
		if(!moveLegal()||TooTall()||tooShort())return false;
		if(mirroringVH(player))return true;
		else if(bothOnSameColor() && mirroringDiag(player))return true;
		return false;}
	
	// mirroring vertical or horizontal
	public boolean mirroringVH(Player player) {
		if(colStart == colEnd && rowStart != rowEnd && steps>=Math.abs(rowStart-rowEnd)) {
			if(mirrorVertical(player)) {
				stackTransaction();didOpponentLose(player);checkBoardHistory(board.toString());switchPlayer();return true;}
		}
		else if(colStart != colEnd && rowStart == rowEnd && steps>=Math.abs(colStart-colEnd)) {			
			if(mirrorHorizontal(player)) {
				stackTransaction();didOpponentLose(player);checkBoardHistory(board.toString());switchPlayer();return true;}
		}
		return false;}
	
	public boolean mirrorVertical(Player player) {
		rowEnd2=rowStart; colEnd2=colStart;
		if(rowEnd == calcPos(rowEnd2,steps))
			return true;
		else{rowEnd2=rowStart; colEnd2=colStart;
			if(rowEnd == calcNeg(rowEnd2,steps))return true;}
		return false;}
	
	public boolean mirrorHorizontal(Player player) {
		rowEnd2=rowStart; colEnd2=colStart;
		if(colEnd == calcPos(colEnd2,steps))return true;
		else {
			rowEnd2=rowStart; colEnd2=colStart;	
			if(colEnd == calcNeg(colEnd2,steps))return true;}
		return false;}
	
	public boolean mirroringDiag(Player player) {
		if(tryPP()) {
			stackTransaction();didOpponentLose(player);checkBoardHistory(board.toString());switchPlayer();return true;}
		if(tryNN()) {
			stackTransaction();didOpponentLose(player);checkBoardHistory(board.toString());switchPlayer();return true;}
		else if(tryPN()) {
			stackTransaction();didOpponentLose(player);checkBoardHistory(board.toString());switchPlayer();return true;}
		else if(tryNP()) {
			stackTransaction();didOpponentLose(player);checkBoardHistory(board.toString());switchPlayer();return true;}
		return false;}
		
	public boolean tryPP() {
		colEnd2=colStart;rowEnd2=rowStart;
			colEnd2 = calcPos(colEnd2,steps);
			rowEnd2 = calcPos(rowEnd2,steps);
		if(rowEnd2==rowEnd && colEnd2==colEnd)
			return true;
		return false;
	}
	public boolean tryNN() {
		colEnd2=colStart;rowEnd2=rowStart;
			rowEnd2 = calcNeg(rowEnd2,steps);
			colEnd2 = calcNeg(colEnd2,steps);
		if(rowEnd2==rowEnd && colEnd2==colEnd)return true;
		return false;
	}
	public boolean tryPN() {
		colEnd2=colStart;rowEnd2=rowStart;
		rowEnd2 = calcPos(rowEnd2,steps);
		colEnd2 = calcNeg(colEnd2,steps);
		if(rowEnd2==rowEnd && colEnd2==colEnd)return true;
		return false;
	}
	public boolean tryNP() {
		colEnd2=colStart;rowEnd2=rowStart;
		rowEnd2 = calcNeg(rowEnd2,steps);
		colEnd2 = calcPos(colEnd2,steps);
		if(rowEnd2==rowEnd && colEnd2==colEnd)return true;
		return false;
	}
	// shift to target in X or Y direction and mirror if needed
	public int calcPos(int c, int l) {
		dimension = c+l;
		if (dimension>6)
			dimension = 6-(dimension-6);
		if(dimension<1)
			calcNeg(0,Math.abs(dimension));
		return dimension;
	}
	// shift to target in -X or -Y direction and mirror if needed
	public int calcNeg(int c,int l) {
		dimension = c-l;
		if (dimension<1)
			dimension = 1-(dimension-1);
		if(dimension>6)
			calcPos(0,dimension);
		return dimension;
	}
		
	public boolean bothOnSameColor() {
		if((rowStart+colStart)%2!=0 && ((rowEnd+colEnd)%2!=0))return true;
		if(((rowStart+colStart)%2)==0 && ((rowEnd+colEnd)%2)==0)return true; 	
		return false;}
	
	// tootall result will be nigated later so that true->false and false->true
	public boolean TooTall() {
		if (getBoardMatrix()[rowStart][colStart].length() > 4 && getBoardMatrix()[rowStart][colStart].length()-steps<=4)
			return false;
		if (getBoardMatrix()[rowStart][colStart].length() <= 4)return false;
		return true;}
	// does all the required changes in the board and history bla bla
	public void stackTransaction() {
		getBoardMatrix()[rowEnd][colEnd] = getBoardMatrix()[rowStart][colStart].substring(0,steps).concat(getBoardMatrix()[rowEnd][colEnd]);
		getBoardMatrix()[rowStart][colStart] = getBoardMatrix()[rowStart][colStart].substring(steps);
	}
	public boolean tooShort() {
		if(getBoardMatrix()[rowStart][colStart].length()<steps)return true;
		return false;
	}
	// save all board templates after each move to check if any case repeats 3 times	
	public void checkBoardHistory(String board){
		boardHistory.add(board);
		counter=0;
		for(String s : boardHistory){
			if(s.equals(board))counter++;
			if(counter >= 3){
				callDraw(bluePlayer);callDraw(redPlayer);
				redPlayer.finishGame();bluePlayer.finishGame();}}}
	// if opponent has no more moves then declare player won
	public void didOpponentLose(Player player){
		counter = 0;
		for(int i=1;i<getBoardMatrix().length-1; i++) {for(int j=1;j<getBoardMatrix()[i].length-1; j++) {
			if(getBoardMatrix()[i][j].length() != 0 && getBoardMatrix()[i][j].charAt(0) != nextPlayerString().charAt(0)) {counter++;break;}}}
		if(counter == 0) {foundLoser(player);}}
	// declares the winner
	public boolean foundLoser(Player player) {
		if (this.redPlayer == player) {finish(redPlayer);}
		else{finish(bluePlayer);}
		return true;
	}

	public boolean moveLegal() {
		// empty fields or moving to the same field isnt allowed
		if (getBoardMatrix()[rowStart][colStart].length() == 0 || (rowStart == rowEnd && colStart == colEnd)) {
			return false;}
		// player only allowed to move stacks with his color on top
		if(getBoardMatrix()[rowStart][colStart].charAt(0) != nextPlayerString().charAt(0)) {
			return false;}
		// player must move stacks higher equal 4 first
		for(int i=0;i<getBoardMatrix().length-1; i++) {for(int j=0;j<getBoardMatrix()[i].length-1; j++) {
			if (getBoardMatrix()[i][j].length()>4 && getBoardMatrix()[i][j].charAt(0) == nextPlayerString().charAt(0) && getBoardMatrix()[rowStart][colStart].length() < getBoardMatrix()[i][j].length()) {
				return false;
			}}}return true;}
}
