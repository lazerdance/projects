package de.tuberlin.sese.swtpp.gameserver.test.deathstacks;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import de.tuberlin.sese.swtpp.gameserver.control.GameController;
import de.tuberlin.sese.swtpp.gameserver.model.Player;
import de.tuberlin.sese.swtpp.gameserver.model.User;
import de.tuberlin.sese.swtpp.gameserver.model.deathstacks.DeathStacksGame;

public class TryMoveTest_Basel{

	User user1 = new User("Alice", "alice");
	User user2 = new User("Bob", "bob");
	
	Player redPlayer = null;
	Player bluePlayer = null;
	DeathStacksGame game = null;
	GameController controller;
	
	String gameType ="deathstacks";
	
	@Before
	public void setUp() throws Exception {
		controller = GameController.getInstance();
		controller.clear();
		
		int gameID = controller.startGame(user1, "", gameType);
		
		game = (DeathStacksGame) controller.getGame(gameID);
		redPlayer = game.getPlayer(user1);

	}
	
	public void startGame(String initialBoard, boolean redNext) {
		controller.joinGame(user2, gameType);		
		bluePlayer = game.getPlayer(user2);
		
		game.setBoard(initialBoard);
		game.setNextPlayer(redNext? redPlayer:bluePlayer);
	}
	
	public void assertMove(String move, boolean red, boolean expectedResult) {
		if (red)
			assertEquals(expectedResult, game.tryMove(move, redPlayer));
		else 
			assertEquals(expectedResult,game.tryMove(move, bluePlayer));
	}
	
	public void assertGameState(String expectedBoard, boolean redNext, boolean finished, boolean draw, boolean redWon) {
		String board = game.getBoard();
				
		assertEquals(expectedBoard,board);
		assertEquals(finished, game.isFinished());
		if (!game.isFinished()) {
			assertEquals(redNext, game.isRedNext());
		} else {
			assertEquals(draw, game.isDraw());
			if (!draw) {
				assertEquals(redWon, redPlayer.isWinner());
				assertEquals(!redWon, bluePlayer.isWinner());
			}
		}
	}

	/*******************************************
	 * !!!!!!!!! To be implemented !!!!!!!!!!!!
	 *******************************************/
	
//	@Test
//	public void exampleTest() {
//		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
//		assertMove("d6-1-d4",true,false);
//		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
//	}
	
	//TODO: implement test cases of same kind as example here	
	
	@Test
	public void moveString8() {
		startGame("rrrrrrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-11-a5",true,true);
		assertGameState(",rr,rr,rr,rr,rr/rrrrrrrrrrr,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryUp() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/rbb,bb,bb,bb,bb,bb",true);
		assertMove("a1-1-a2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/r,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}

	@Test
	public void tryDown() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("f6-1-f5",true,true);
		assertGameState("rr,rr,rr,rr,rr,r/,,,,,r/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryLeft() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c6-2-a6",true,true);
		assertGameState("rrrr,rr,,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalUpRight() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,rbb,bb,bb,bb,bb",true);
		assertMove("b1-1-c2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,r,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalUpRight2() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/rbb,bb,bb,bb,bb,bb",true);
		assertMove("a1-1-b2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,r,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalUpRight22() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bbb,bb,bb,bb,bb,bb",false);
		assertMove("a1-2-c3",false,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,bb,,,/,,,,,/b,bb,bb,bb,bb,bb",true,false,false,false);
	}
	@Test
	public void tryDiagonalUpRight222() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bbb,bb,bb,bb,bb,bb",false);
		assertMove("b1-1-a2",false,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/b,,,,,/bbb,b,bb,bb,bb,bb",true,false,false,false);
	}
	
	@Test
	public void tryDiagonalUpLeft() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,rbb,bb,bb,bb,bb",true);
		assertMove("b1-1-a2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/r,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalUpLeft1() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("f1-1-f2",false,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,b/bb,bb,bb,bb,bb,b",true,false,false,false);
	}
	
	@Test
	public void tryF1IsEmpty() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,",false);
		assertMove("f1-1-f2",false,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,",false,false,false,false);
	}
	
	@Test
	public void tryDiagonalUpLeft2() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,rbb,bb,bb,bb,bb",true);
		assertMove("b1-1-a2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/r,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalDownLeft() {
		startGame("rr,rrr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b6-1-a5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalDownLeftSpiegel() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,rrr,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c2-3-b3",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,rrr,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryDiagonalSpiegel() {
		startGame("rr,rrr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,rrr,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b2-3-c3",true,true);
		assertGameState("rr,rrr,rr,rr,rr,rr/,,,,,/,,,,,/,,rrr,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryDiagonalDownLeft2() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("f6-1-e5",true,true);
		assertGameState("rr,rr,rr,rr,rr,r/,,,,r,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryDiagonalDownRight() {
		startGame("rrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-b5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,r,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalDownRightSpiegel() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,rrr,,/bb,bb,bb,rrr,bb,bb",true);
		assertMove("d2-3-e3",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,rrr,/,,,,,/bb,bb,bb,rrr,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryDiagonalDownRightSpiegelEck() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,rrr,/bb,bb,bb,rrr,bb,bb",true);
		assertMove("e2-3-d3",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,rrr,,/,,,,,/bb,bb,bb,rrr,bb,bb",false,false,false,false);
	}
	
	
	@Test
	public void tryMirroringDownLeft() {
		startGame("rr,rrrr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b6-3-c3",true,true);
		assertGameState("rr,r,rr,rr,rr,rr/,,,,,/,,,,,/,,rrr,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringDownRight() {
		startGame("rr,rr,rr,rrrr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("d6-3-e3",true,true);
		assertGameState("rr,rr,rr,r,rr,rr/,,,,,/,,,,,/,,,,rrr,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringupRight() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,rrrbb,bb,bb",true);
		assertMove("d1-3-e4",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,rrr,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringUpLeft() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,rrrbb,bb,bb,bb,bb",true);
		assertMove("b1-3-c4",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,rrr,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringUp() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,rrr,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b4-3-b5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,rrr,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringDown() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,rrr,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("d3-3-d2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,rrr,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringLeft() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,rrr,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c3-3-b3",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,rrr,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringRight() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,rrr,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("e5-3-d5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,rrr,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryTooTall() {
		startGame("rr,rr,rr,rr,rr,rrrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("f6-1-f5",true,false);
		assertGameState("rr,rr,rr,rr,rr,rrrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	
	@Test  // failed red tootall with red access
	public void tryTooTallAa1() {
		startGame("rrrrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a1-1-a2",true,false);
		assertGameState("rrrrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
		
	@Test // red tootall with red access
	public void tryTooTall4a() {
		startGame("rrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-4-a2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/rrrr,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test // red tootall with red access
	public void tryTooTall4() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/rrrrbb,bb,bb,bb,bb,bb",true);
		assertMove("a1-4-a5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/rrrr,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test // blue tootall with blue access
	public void tryTooTall3() {
		startGame("rr,rr,rr,rr,rr,brrrrrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("f6-5-f1",false,true);
		assertGameState("rr,rr,rr,rr,rr,rrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,brrrrbb",true,false,false,false);
	}
	
	
	@Test // failed blue tootall
	public void tryTooTalla1() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bbbbbb,bb,bb,bb,bb,bb",true);
		assertMove("a1-1-a2",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bbbbbb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	
	
	@Test
	public void TooTall_r_r() {
		startGame("rr,rr,rr,rr,rr,rrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-a5",true,false);
		assertGameState("rr,rr,rr,rr,rr,rrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	
	
	@Test
	public void TooTall_b_r() {
		startGame("rr,rr,rr,rr,rr,brrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-a5",true,true);
		assertGameState("r,rr,rr,rr,rr,brrrr/r,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void TooTall_b_b() {
		startGame("br,rr,rr,rr,rr,brrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("a6-1-a5",false,false);
		assertGameState("br,rr,rr,rr,rr,brrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void TooTall_r_b() {
		startGame("br,rr,rr,rr,rr,rrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("a6-1-a5",false,true);
		assertGameState("r,rr,rr,rr,rr,rrrrr/b,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}	
	
	
	@Test
	public void trynotValidMove() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-2-a5",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	@Test
	public void tryOwnStone() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a1-1-a2",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	@Test
	public void tryOwnStoneBl() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("a6-1-a5",false,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryBackToSameCell() {
		startGame("rr,rr,rr,rr,rr,rrrrrrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-a6",true,false);
		assertGameState("rr,rr,rr,rr,rr,rrrrrrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}

	@Test 
	public void tryRedWins() {
		startGame("rr,rr,rr,rr,rr,rrr/,,,,,/,,,,,/,,,,,/r,,,,,/bb,rbb,rbb,rbb,rbb,rbb",true);
		assertMove("a2-1-a1",true,true);
		assertGameState("rr,rr,rr,rr,rr,rrr/,,,,,/,,,,,/,,,,,/,,,,,/rbb,rbb,rbb,rbb,rbb,rbb",false,true,false,true);
	}
	@Test
	public void tryBlueWins() {
		startGame("brr,brr,brr,brr,brr,brr/,,,,,/,,,,,/,,,,,/r,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("a1-1-a2",false,true);
		assertGameState("brr,brr,brr,brr,brr,brr/,,,,,/,,,,,/,,,,,/br,,,,,/b,bb,bb,bb,bb,bb",false,true,false,false);
	}
	@Test
	public void tryRepeating() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-a5",true,true);
		assertGameState("r,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
		assertMove("a1-1-a2",false,true);
		assertGameState("r,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/b,,,,,/b,bb,bb,bb,bb,bb",true,false,false,false);
		assertMove("a5-1-a6",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/b,,,,,/b,bb,bb,bb,bb,bb",false,false,false,false);
		assertMove("a2-1-a1",false,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
		assertMove("a6-1-a5",true,true);
		assertGameState("r,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
		assertMove("a1-1-a2",false,true);
		assertGameState("r,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/b,,,,,/b,bb,bb,bb,bb,bb",true,false,false,false);
		assertMove("a5-1-a6",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/b,,,,,/b,bb,bb,bb,bb,bb",false,false,false,false);
		assertMove("a2-1-a1",false,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,true,true,false);
	}
	
	
	
	@Test
	public void emptyCell() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a5-1-a4",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	@Test
	public void tryPsCellfuel() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-3-a3",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	@Test
	public void tryPsCellfuelq() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a1-3-a4",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	
}
