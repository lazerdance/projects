package de.tuberlin.sese.swtpp.gameserver.test.deathstacks;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import de.tuberlin.sese.swtpp.gameserver.control.GameController;
import de.tuberlin.sese.swtpp.gameserver.model.Player;
import de.tuberlin.sese.swtpp.gameserver.model.User;
import de.tuberlin.sese.swtpp.gameserver.model.deathstacks.DeathStacksGame;

public class TryMoveTest {

	User user1 = new User("Alice", "alice");
	User user2 = new User("Bob", "bob");
	
	Player redPlayer = null;
	Player bluePlayer = null;
	DeathStacksGame game = null;
	GameController controller;
	
	String gameType ="deathstacks";
	
	@Before
	public void setUp() throws Exception {
		controller = GameController.getInstance();
		controller.clear();
		
		int gameID = controller.startGame(user1, "", gameType);
		
		game = (DeathStacksGame) controller.getGame(gameID);
		redPlayer = game.getPlayer(user1);

	}
	
	public void startGame(String initialBoard, boolean redNext) {
		controller.joinGame(user2, gameType);		
		bluePlayer = game.getPlayer(user2);
		
		game.setBoard(initialBoard);
		game.setNextPlayer(redNext? redPlayer:bluePlayer);
	}
	
	public void assertMove(String move, boolean red, boolean expectedResult) {
		if (red)
			assertEquals(expectedResult, game.tryMove(move, redPlayer));
		else 
			assertEquals(expectedResult,game.tryMove(move, bluePlayer));
	}
	
	public void assertGameState(String expectedBoard, boolean redNext, boolean finished, boolean draw, boolean redWon) {
		String board = game.getBoard();
				
		assertEquals(expectedBoard,board);
		assertEquals(finished, game.isFinished());
		if (!game.isFinished()) {
			assertEquals(redNext, game.isRedNext());
		} else {
			assertEquals(draw, game.isDraw());
			if (!draw) {
				assertEquals(redWon, redPlayer.isWinner());
				assertEquals(!redWon, bluePlayer.isWinner());
			}
		}
	}

	/*******************************************
	 * !!!!!!!!! To be implemented !!!!!!!!!!!!
	 *******************************************/
	
	@Test
	public void exampleTest() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("d6-1-d4",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}

	//TODO: implement test cases of same kind as example here
	@Test
	public void testMoveHorizontal() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		System.out.println("horizontal move should be successfull a6-2-c6");
		assertMove("a6-2-d6",true,false);
		assertMove("a6-2-c6",true,true);
		assertGameState(",rr,rrrr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
		
	}
	@Test
	public void testMoveVertical() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		System.out.println("vertical move should be successfull a6-2-a4");
		assertMove("a6-2-a5",true,false);
		assertMove("a6-2-a4",true,true);
		assertGameState(",rr,rr,rr,rr,rr/,,,,,/rr,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void testMirrorXTo_X() {
		System.out.println("horizontal mirroring should be successfull e5-5-b5");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,rrrrrrrrrrrrrrrrrr,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("e4-6-b4",true,false);
		assertMove("e4-16-c4",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,rrrrrrrrrrrrrrrr,,rr,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void testMirrorXTo_XFailed() {
		System.out.println("horizontal mirroring should be successfull e5-5-b5");
		startGame("rr,rr,rr,rr,rrrrrrrr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("e6-6-b6",true,false);
		assertGameState("rr,rr,rr,rr,rrrrrrrr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	@Test
	public void testMirror_XToX() {
		System.out.println("horizontal mirroring should be successfull e5-5-b5");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,rrrrrrr,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b3-5-e3",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,rr,,,rrrrr,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void testMirrorYTo_Y() {
		System.out.println("horizontal mirroring should be successfull e5-5-e2");
		startGame("rr,rr,rr,rr,rr,rr/,,,,rrrrrrr,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("e5-6-e2",true,false);
		assertMove("e5-5-e2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,rr,/,,,,,/,,,,,/,,,,rrrrr,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void testMirror_YToY() {
		System.out.println("horizontal mirroring should be successfull e2-5-e5");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,rrrrrrr,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c2-6-c5",true,false);
		assertMove("c2-5-c5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,rrrrr,,,/,,,,,/,,,,,/,,rr,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void testNormalDiagonalN() {
		System.out.println("Diagonal Move should be successfull e6-3-b3");
		startGame("rr,rr,rr,rr,rrrrrr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("e6-3-d4",true,false);
		assertMove("e6-3-b3",true,true);
		assertGameState("rr,rr,rr,rr,rrr,rr/,,,,,/,,,,,/,rrr,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void testNormalDiagonalpn() {
		System.out.println("Diagonal Move should be successfull e6-3-b3");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,rrr,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("d4-3-e6",true,false);
		assertMove("c4-3-f1",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,rrrbb",false,false,false,false);
	}	
	@Test
	public void testNormalDiagonalnp() {
		System.out.println("Diagonal Move should be successfull e6-3-b3");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,rrrbb",true);
		assertMove("d4-3-e6",true,false);
		assertMove("f1-3-c4",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,rrr,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void testDiagonalMirroring() {
		System.out.println("Diagonal Move should be successfull e6-3-b3");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,rrrrrrr,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("d4-3-e6",true,false);
		assertMove("c3-7-b6",true,true);
		assertGameState("rr,rrrrrrrrr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void testNormalDiagonalp() {
		System.out.println("Diagonal Move should be successfull e6-3-b3");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,rrr,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("d4-3-e6",true,false);
		assertMove("b3-3-e6",true,true);
		assertGameState("rr,rr,rr,rr,rrrrr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void testDiameterMirroring() {
		System.out.println("Diagonal Move should be successfull e6-3-b3");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,rrrrrrrr,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c4-5-e3",true,false);
		assertMove("c4-5-e2",true,false);
		assertMove("c4-5-d3",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,rrr,,,/,,,rrrrr,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void testMirroringCircleNN() {
		System.out.println("Diagonal Move should be successfull e6-3-b3");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,rrrrrrrr,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c2-5-e6",true,false);
		assertMove("c2-6-e6",true,true);
		assertGameState("rr,rr,rr,rr,rrrrrrrr,rr/,,,,,/,,,,,/,,,,,/,,rr,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void testMirroringCirclePP() {
		System.out.println("Diagonal Move should be successfull e6-3-b3");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,rrrrrrrrrrrrrrrrrrr,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("d3-15-e6",true,false);
		assertMove("d3-17-a2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,rr,,/rrrrrrrrrrrrrrrrr,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void testMirroringCircle_xyPN() {
		System.out.println("Diagonal Move should be successfull e6-3-b3");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,rrrrrrrrrrrrrrrrrrr,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b2-5-c5",true,false);
		assertMove("b3-17-e2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,rr,,,,/,,,,rrrrrrrrrrrrrrrrr,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void testMirroringCirclex_yNP() {
		System.out.println("Diagonal Move should be successfull e6-3-b3");
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,rrrrrrrrrrrrrrrrrrr,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b2-5-c5",true,false);
		assertMove("b3-17-c6",true,true);
		assertGameState("rr,rr,rrrrrrrrrrrrrrrrrrr,rr,rr,rr/,,,,,/,,,,,/,rr,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	

	@Test
	public void testTooTall() {
		startGame("rrrrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c4-5-e3",true,false);
		assertMove("a6-3-a3",true,false);
		assertMove("a6-5-a1",true,true);
		assertGameState("rrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/rrrrrbb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void testTooShort() {
		startGame("rrrrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c4-5-e3",true,false);
		assertMove("a6-3-a3",true,false);
		assertMove("a6-5-a1",true,true);
		assertGameState("rrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/rrrrrbb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void noMoreStacks() {
		startGame("rrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,,,,,",true);
		assertMove("a6-5-a1",true,true);		// same field
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/rrrrrbb,,,,,",false,true,false,true);
	}	
	@Test
	public void noMoreStacks2() {
		startGame("rr,,,,,/,,,,,/,,,,,/,,,,,/,,,,,/bbbbbbb,,,,,",false);
		assertMove("a1-5-a6",false,true);		// same field
		assertGameState("bbbbbrr,,,,,/,,,,,/,,,,,/,,,,,/,,,,,/bb,,,,,",false,true,false,false);
	}	
	@Test
	public void higherStacksFirst() {
		startGame("rrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,,,,,",true);
		assertMove("a5-2-a3",true,false);
		assertGameState("rrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,,,,,",true,false,false,true);
	}	
	@Test
	public void testMoveLegal() {
		startGame("rrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-a6",true,false);		// same field
		assertMove("a5-1-a4",true,false);		// empty field
		assertMove("a1-1-a2",true,false);		// opponent's stack
		assertMove("c6-1-c5",true,true);		// correct move
		assertGameState("rrrr,rr,r,rr,rr,rr/,,r,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}	
	@Test
	public void test3TimesSameState() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		game.tryMove("a6-1-a5", redPlayer);
		game.tryMove("a1-1-a2", bluePlayer);
		game.tryMove("a5-1-a6", redPlayer);
		game.tryMove("a2-1-a1", bluePlayer);
		game.tryMove("a6-1-a5", redPlayer);
		game.tryMove("a1-1-a2", bluePlayer);
		game.tryMove("a5-1-a6", redPlayer);
		game.tryMove("a2-1-a1", bluePlayer);
		game.tryMove("a6-1-a5", redPlayer);
		assertGameState("r,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,true,true,false);
	}	
	
	@Test
	public void tryTooTall() {
		startGame("rr,rr,rr,rr,rr,rrrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("f6-1-f5",true,false);
		assertGameState("rr,rr,rr,rr,rr,rrrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	
	@Test  // failed red tootall with red access
	public void tryTooTallAa1() {
		startGame("rrrrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a1-1-a2",true,false);
		assertGameState("rrrrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
		
	@Test // red tootall with red access
	public void tryTooTall4a() {
		startGame("rrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-4-a2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/rrrr,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test // red tootall with red access
	public void tryTooTall4() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/rrrrbb,bb,bb,bb,bb,bb",true);
		assertMove("a1-4-a5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/rrrr,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test // blue tootall with blue access
	public void tryTooTall3() {
		startGame("rr,rr,rr,rr,rr,brrrrrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("f6-5-f1",false,true);
		assertGameState("rr,rr,rr,rr,rr,rrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,brrrrbb",true,false,false,false);
	}
	
	
	@Test // failed blue tootall
	public void tryTooTalla1() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bbbbbb,bb,bb,bb,bb,bb",true);
		assertMove("a1-1-a2",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bbbbbb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	
	
	@Test
	public void TooTall_r_r() {
		startGame("rr,rr,rr,rr,rr,rrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-a5",true,false);
		assertGameState("rr,rr,rr,rr,rr,rrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	
	
	@Test
	public void TooTall_b_r() {
		startGame("rr,rr,rr,rr,rr,brrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-a5",true,true);
		assertGameState("r,rr,rr,rr,rr,brrrr/r,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void TooTall_b_b() {
		startGame("br,rr,rr,rr,rr,brrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("a6-1-a5",false,false);
		assertGameState("br,rr,rr,rr,rr,brrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void TooTall_r_b() {
		startGame("br,rr,rr,rr,rr,rrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("a6-1-a5",false,true);
		assertGameState("r,rr,rr,rr,rr,rrrrr/b,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}	
	
	
	@Test
	public void trynotValidMove() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-2-a5",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}	
	
	
	
// basel Teil
	
	@Test
	public void moveString8() {
		startGame("rrrrrrrrrrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-11-a5",true,true);
		assertGameState(",rr,rr,rr,rr,rr/rrrrrrrrrrr,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryUp() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/rbb,bb,bb,bb,bb,bb",true);
		assertMove("a1-1-a2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/r,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}

	@Test
	public void tryDown() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("f6-1-f5",true,true);
		assertGameState("rr,rr,rr,rr,rr,r/,,,,,r/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryLeft() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c6-2-a6",true,true);
		assertGameState("rrrr,rr,,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalUpRight() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,rbb,bb,bb,bb,bb",true);
		assertMove("b1-1-c2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,r,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalUpRight2() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/rbb,bb,bb,bb,bb,bb",true);
		assertMove("a1-1-b2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,r,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalUpRight22() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bbb,bb,bb,bb,bb,bb",false);
		assertMove("a1-2-c3",false,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,bb,,,/,,,,,/b,bb,bb,bb,bb,bb",true,false,false,false);
	}
	@Test
	public void tryDiagonalUpRight222() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bbb,bb,bb,bb,bb,bb",false);
		assertMove("b1-1-a2",false,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/b,,,,,/bbb,b,bb,bb,bb,bb",true,false,false,false);
	}
	
	@Test
	public void tryDiagonalUpLeft() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,rbb,bb,bb,bb,bb",true);
		assertMove("b1-1-a2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/r,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalUpLeft1() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("f1-1-f2",false,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,b/bb,bb,bb,bb,bb,b",true,false,false,false);
	}
	
	@Test
	public void tryF1IsEmpty() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,",false);
		assertMove("f1-1-f2",false,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,",false,false,false,false);
	}
	
	@Test
	public void tryDiagonalUpLeft2() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,rbb,bb,bb,bb,bb",true);
		assertMove("b1-1-a2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/r,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalDownLeft() {
		startGame("rr,rrr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b6-1-a5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalDownLeftSpiegel() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,rrr,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c2-3-b3",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,rrr,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryDiagonalSpiegel() {
		startGame("rr,rrr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,rrr,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b2-3-c3",true,true);
		assertGameState("rr,rrr,rr,rr,rr,rr/,,,,,/,,,,,/,,rrr,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryDiagonalDownLeft2() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("f6-1-e5",true,true);
		assertGameState("rr,rr,rr,rr,rr,r/,,,,r,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryDiagonalDownRight() {
		startGame("rrr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-b5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,r,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryDiagonalDownRightSpiegel() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,rrr,,/bb,bb,bb,rrr,bb,bb",true);
		assertMove("d2-3-e3",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,rrr,/,,,,,/bb,bb,bb,rrr,bb,bb",false,false,false,false);
	}
	
	@Test
	public void tryDiagonalDownRightSpiegelEck() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,rrr,/bb,bb,bb,rrr,bb,bb",true);
		assertMove("e2-3-d3",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,rrr,,/,,,,,/bb,bb,bb,rrr,bb,bb",false,false,false,false);
	}
	
	
	@Test
	public void tryMirroringDownLeft() {
		startGame("rr,rrrr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b6-3-c3",true,true);
		assertGameState("rr,r,rr,rr,rr,rr/,,,,,/,,,,,/,,rrr,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringDownRight() {
		startGame("rr,rr,rr,rrrr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("d6-3-e3",true,true);
		assertGameState("rr,rr,rr,r,rr,rr/,,,,,/,,,,,/,,,,rrr,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringupRight() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,rrrbb,bb,bb",true);
		assertMove("d1-3-e4",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,rrr,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringUpLeft() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,rrrbb,bb,bb,bb,bb",true);
		assertMove("b1-3-c4",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,rrr,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringUp() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,rrr,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("b4-3-b5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,rrr,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringDown() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,rrr,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("d3-3-d2",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,rrr,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringLeft() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,rrr,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("c3-3-b3",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,rrr,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryMirroringRight() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,rrr,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("e5-3-d5",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,rrr,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	
	
	@Test
	public void tryOwnStone() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a1-1-a2",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	@Test
	public void tryOwnStoneBl() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("a6-1-a5",false,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
	}
	@Test
	public void tryBackToSameCell() {
		startGame("rr,rr,rr,rr,rr,rrrrrrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-a6",true,false);
		assertGameState("rr,rr,rr,rr,rr,rrrrrrrrr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}

	@Test 
	public void tryRedWins() {
		startGame("rr,rr,rr,rr,rr,rrr/,,,,,/,,,,,/,,,,,/r,,,,,/bb,rbb,rbb,rbb,rbb,rbb",true);
		assertMove("a2-1-a1",true,true);
		assertGameState("rr,rr,rr,rr,rr,rrr/,,,,,/,,,,,/,,,,,/,,,,,/rbb,rbb,rbb,rbb,rbb,rbb",false,true,false,true);
	}
	@Test
	public void tryBlueWins() {
		startGame("brr,brr,brr,brr,brr,brr/,,,,,/,,,,,/,,,,,/r,,,,,/bb,bb,bb,bb,bb,bb",false);
		assertMove("a1-1-a2",false,true);
		assertGameState("brr,brr,brr,brr,brr,brr/,,,,,/,,,,,/,,,,,/br,,,,,/b,bb,bb,bb,bb,bb",false,true,false,false);
	}
	@Test
	public void tryRepeating() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-1-a5",true,true);
		assertGameState("r,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
		assertMove("a1-1-a2",false,true);
		assertGameState("r,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/b,,,,,/b,bb,bb,bb,bb,bb",true,false,false,false);
		assertMove("a5-1-a6",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/b,,,,,/b,bb,bb,bb,bb,bb",false,false,false,false);
		assertMove("a2-1-a1",false,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
		assertMove("a6-1-a5",true,true);
		assertGameState("r,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",false,false,false,false);
		assertMove("a1-1-a2",false,true);
		assertGameState("r,rr,rr,rr,rr,rr/r,,,,,/,,,,,/,,,,,/b,,,,,/b,bb,bb,bb,bb,bb",true,false,false,false);
		assertMove("a5-1-a6",true,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/b,,,,,/b,bb,bb,bb,bb,bb",false,false,false,false);
		assertMove("a2-1-a1",false,true);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,true,true,false);
	}
	
	
	
	@Test
	public void emptyCell() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a5-1-a4",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	@Test
	public void tryPsCellfuel() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a6-3-a3",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	@Test
	public void tryPsCellfuelq() {
		startGame("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true);
		assertMove("a1-3-a4",true,false);
		assertGameState("rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb",true,false,false,false);
	}
	
	
	
}
