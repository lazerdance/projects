--------------------------------------------------------------------------------------------
--- Authoren :: Amro Hendawi -> Leon Marius Moll -> Saarujan Sritharan -> DeathStacksBot ---
--------------------------------------------------------------------------------------------
-----v 1.1-----

--- module (NICHT AENDERN!)
module DeathStacksBot where
--- imports (NICHT AENDERN!)
import Data.Char
import Util

--- external signatures (NICHT AENDERN!)
getMove :: String -> String
listMoves :: String -> String
getMove state = (movesList state) !! (((length(movesList state))*7+13) `mod` (length(movesList state)))
listMoves state = init(concat(map (++ ",") (rmdups (Util.splitOn "," (init((allMovesFiltered state) ++ (allDiagonalMoves state)))))))

movesList state = (rmdups (Util.splitOn "," (init((allMovesFiltered state) ++ (allDiagonalMoves state))))) 
--- YOUR IMPLEMENTATION STARTS HERE ---

fieldIsEmpty :: [[[Char]]] -> Int -> Int -> Bool
fieldIsEmpty board row col = length (((board !! row ) !! col )) == 0

splitRowEnd :: [Char] -> [[Char]]
splitRowEnd state = Util.splitOn "/" state

splitRowEndL :: [Char] -> [[Char]]
splitRowEndL state = Util.splitOn " " state

splitColEnd :: [Char] -> [[Char]]
splitColEnd state = Util.splitOn "," state

matrix :: [Char] -> [[[Char]]]
matrix board = let x = splitRowEnd (init(init board)) in map splitColEnd x

replaceO [] = []
replaceO (x:xs) = 
     if x == '/' 
     then ',' : replaceO xs 
     else x : replaceO xs

-- extract player stacks locations and player color
stacksCoords state = zip ["a6","b6","c6","d6","e6","f6","a5","b5","c5","d5","e5","f5","a4","b4","c4","d4","e4","f4","a3","b3","c3","d3","e3","f3","a2","b2","c2","d2","e2","f1","a1","b1","c1","d1","e1","f1"] (splitColEnd (concat (splitRowEnd (init(init(replaceO state))))))
stacksFields state = let y = stacksCoords state in filter (((/="")).snd) y
playerFields state = let x = stacksFields state in filter (((==(last(state))).head).snd) x
getPlayer string = last (string)

stringToList state = splitColEnd (concat (splitRowEnd (init(init(replaceO state)))))
        
charToInt :: Char -> Int
charToInt c  | c =='a' = 1 | c =='b' = 2 | c =='c' = 3 | c =='d' = 4 | c =='e' = 5 | c =='f' = 6
                
zahlToInt :: Char -> Int
zahlToInt c  | c == '1' = 1 | c == '2' = 2 | c == '3' = 3 | c == '4' = 4 | c == '5' = 5 | c == '6' = 6

intToZahl :: Int -> Char
intToZahl i  | i == 1 = '1' | i == 2 = '2' | i == 3 = '3' | i == 4 = '4' | i == 5 = '5' | i == 6 = '6'

intToChar :: Int -> Char
intToChar i  | i == 1 = 'a' | i == 2 = 'b' | i == 3 = 'c' | i == 4 = 'd' | i == 5 = 'e' | i == 6 = 'f'

intToString :: Int -> [Char]
intToString i  | i == 0 = "0" | i == 1 = "1" | i == 2 = "2" | i == 3 = "3" | i == 4 = "4" | i == 5 = "5" | i == 6 = "6"
               | i == 7 = "7" | i == 8 = "8" | i == 9 = "9" | i == 10 = "10" | i == 11 = "11" | i == 12 = "12"
               | i == 13 = "13" | i == 14 = "14" | i == 15 = "15" | i == 16 = "16" | i == 17 = "17" | i == 18 = "18"
               | i == 19 = "19" | i == 20 = "20" | i == 21 = "21" | i == 22 = "22" | i == 23 = "23" | i == 24 = "24"
intToStrChar :: Int -> [Char]
intToStrChar i  | i == 1 = "a" | i == 2 = "b" | i == 3 = "c" | i == 4 = "d" | i == 5 = "e" | i == 6 = "f"
                | i == 7 = "a"  | i == 8 = "b" | i == 9 = "c" | i == 10 = "d" | i == 11 = "e" | i == 12 = "f"
stringToInt :: [Char] -> Int
stringToInt i  | i == "1" = 1 | i == "2" = 2 | i == "3" = 3 | i == "4" = 4 | i == "5" = 5 | i == "6" = 6

charToString :: Char -> [Char]
charToString i  | i == '1' = "a" | i == '2' = "b" | i == '3' = "c" | i == '4' = "d" | i == '5' = "e" | i == '6' = "f"

charLetterToString :: Char -> [Char]
charLetterToString i  | i == 'a' = "a" | i == 'b' = "b" | i == 'c' = "c" | i == 'd' = "d" | i == 'e' = "e" | i == 'f' = "f"

calcInterval start length  = if  length>= 9 then interval 1 6
                             else if start+length <=6 then interval start (length+start)
                             else if (start+length >6) && ((calcPlus start length) > start)  then interval start 6
                             else if (calcPlus start length) <= start then interval (calcPlus start length) 6
                             else []

calcIntervalm start length  = if  length >= 9 then interval 1 6
                             else if (calcMinus start length) >= start then interval  1 (calcMinus start length)
                             else if (start-length == 0) then interval 1 start
                             else if (start-length) >=1 then interval (abs (start-length)) start
                             else []

interval x lengthX = [x..lengthX]
mapPairs xs ys =
    do
        x <- xs
        y <- ys
        return (x,y)

-- move calculator (x/y++) or (x/y--) -> steps
calcPluss :: Int -> Int ->Int
calcPluss x l = if (x + l) > 6
                    then 6 - (x + l - 6)
                    else (x + l)

calcMinuss :: Int -> Int ->Int
calcMinuss x l = if (x - l) < 1
                    then 1 - (x - l - 1)
                    else (x - l)
-- move loop works for infinit positiv numbers
calcPlus x l = if (calcPluss x l) < 1
                then (calcMinus 0 (abs(calcPluss x l)))
                else (calcPluss x l)

calcMinus x l = if (calcMinuss x l) > 6
                then (calcPlus 0 (abs(calcMinuss x l)))
                else (calcMinuss x l)
    

-- calcXmoves :: (a,a) -> [a]
calcXmoves x =  rmdups (merge (calcIntervalm (charToInt (head(fst(x)))) (length(snd(x)))) (calcInterval (charToInt (head(fst(x)))) (length(snd(x)))));
calcYmoves y = rmdups (merge (calcIntervalm (stringToInt(tail(fst(y)))) (length(snd(y)))) (calcInterval (stringToInt(tail(fst(y)))) (length(snd(y)))))
moveVertical y = mapPairs [(charToInt (head(fst(y))))] (calcYmoves y)
moveHorizontal x = mapPairs (calcXmoves x) [(stringToInt(tail(fst(x))))]

-- gives all combinations from two lists (valid and invalid moves)
possibleMoves a = mapPairs (calcXmoves a) (calcYmoves a)
allHoriVerti a = (moveVertical a) ++ (moveHorizontal a) 

-- calculate length only for horizontal and vertical as a list -----------
calcLengthVH a = zipWith (+) (distX a) (distY a)
lengthToStr a = let ys = (calcLengthVH a) in [intToString(i) | i <- ys]
distX a = let ys = (allHoriVerti a) in [abs(fst(i)-(charToInt(head(fst(a))))) | i <- ys]
distY a = let ys = (allHoriVerti a) in [abs(snd(i)-(stringToInt(tail(fst(a))))) | i <- ys]
targetString a = let ys = (allHoriVerti a) in [(intToStrChar(fst(i))) ++ (intToString(snd(i))) | i <- ys]
---------------------------------------------------------------------------
--------------------- mirroring section -------------------------------------------
moveX a l = calcPlus (charToInt(head(fst(a)))) (l`mod`10)
moveY a l = calcPlus (stringToInt(tail(fst(a)))) (l`mod`10)
move_X a l = calcMinus (charToInt(head(fst(a)))) (l`mod`10)
move_Y a l = calcMinus (stringToInt(tail(fst(a)))) (l`mod`10)

case_XY a l = (fst(a)) ++ "-"  ++ (intToString(l)) ++ "-" ++ (intToStrChar(move_X a l)) ++ (intToString(moveY a l))
caseXY a l = (fst(a)) ++ "-"  ++ (intToString(l)) ++ "-" ++ (intToStrChar(moveX a l)) ++ (intToString(moveY a l))
caseX_Y a l = (fst(a)) ++ "-"  ++ (intToString(l)) ++ "-" ++ (intToStrChar(moveX a l)) ++ (intToString(move_Y a l))
case_X_Y a l = (fst(a)) ++ "-"  ++ (intToString(l)) ++ "-" ++ (intToStrChar(move_X a l)) ++ (intToString(move_Y a l))

fourCases a l= (caseXY a l) ++ "," ++ (case_X_Y a l) ++ "," ++ (case_XY a l) ++ "," ++ (caseX_Y a l)
fourCasesGlobal a = let x = (interval 1 (length(snd(a)))) in map (fourCases a ) x

allDiagonalMoves state = concat (map (++ ",") (concat(map (fourCasesGlobal) (playerFields state))))
------------------------------------------------------------------------------------
marshallVH1 a = let ys = (calcLengthVH a)
                in [fst(a) ++ "-" ++ (intToString(j)) ++ "-"| j <- ys ]
marshallVH a = zipWith (++) (marshallVH1 a) (targetString a)
-- allVHMoves state = concat (map (++ ",") (concat(map (marshallVH) (playerFields state))))
allVHMoves state = (concat(map (marshallVH) (playerFields state)))

allMovesFiltered state = concat (map (++ ",") (filterZero (allVHMoves state)))

-- filterZero :: Eq a => [a] -> [a]
filterZero [] = []
filterZero (x:xs)   | any (=='0') x   = filterZero xs
                    | otherwise     = x : filterZero xs


allMoves state = concat(map (++ ",") (rmdups (Util.splitOn "," (init((allMovesFiltered state) ++ (allDiagonalMoves state))))))

-- distX a = abs((fst((allHoriVerti a) !! 0)) - charToInt(head(fst(a))))
-- distY a = abs((snd((allHoriVerti a) !! 0)) - stringToInt(tail(fst(a))))
-- mergeCoords tuple = let x = possibleMoves in map mergeTuple x
mergeCoords y = map mergeTuple (moveVertical y)
-- coordsIntToChar = map intToChar mergeCoords
-- coordToChar = intToChar (fst(moveVertical))
-- coordToChar = let x = mergeCoords in ((charToString).head) x
-- coordToChar = map stringToString mergeCoords

intersect :: Eq a => [a] -> [a] -> [a]
intersect [] _ = []
intersect (x:xs) ys
    | x `elem` ys = x : intersect xs ys
    | otherwise = intersect xs ys

merge :: [a] -> [a] -> [a]
merge xs     []     = xs
merge []     ys     = ys
merge (x:xs) (y:ys) = x : y : merge xs ys

mergeTuple :: (Int,Int) -> [Char]
mergeTuple tuple = (intToString(fst(tuple))) ++ (intToString(snd(tuple)))

rmdups :: Eq a => [a] -> [a]
rmdups [] = []
rmdups (x:xs)   | x `elem` xs   = rmdups xs
                | otherwise     = x : rmdups xs